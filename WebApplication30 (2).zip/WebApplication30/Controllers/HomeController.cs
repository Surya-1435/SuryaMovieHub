﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication30.Models.NewFolder1;
using WebApplication30.Models;

namespace WebApplication30.Controllers
{
    public class HomeController : Controller
    {
        Class1Context dal = new Class1Context();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About(Class1 p)
        {
            p.anyName = Request.Files;
            HttpPostedFileBase a = p.anyName[0];
            string s = "~/images/store/" + a.FileName;
            p.ImagePath = s;
            a.SaveAs(Server.MapPath(p.ImagePath));
            dal.result.Add(p);
            dal.SaveChanges();
            List<Class1> li = dal.result.ToList();
            return View("About", li);


        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult info(string image, string moviedes, int id, string trail)
        {
            Class1 p = new Class1();
            p.MovieId = id;
            p.MovieDescription = moviedes;
            p.ImagePath = image;
            p.trailer = trail;
            return View("info", p);
        }
        public ActionResult info2(string image, string moviedes, int id)
        {
            Class2 p = new Class2();
            p.MovieId = id;
            p.MovieDescription = moviedes;
            p.ImagePath = image;
            return View("info2", p);
        }
    }
}