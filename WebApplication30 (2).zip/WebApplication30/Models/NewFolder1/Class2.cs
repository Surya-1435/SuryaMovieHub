﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication30.Models.NewFolder1
{
    public class Class2
    {
        
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required]
        public int MovieId { get; set; }
        [Required]
        [Key]
        public string MovieName { get; set; }
        [Required]
        public string trailer { get; set; }
        [Required]
        public string MovieDescription { get; set; }
        [Required]
        public string ImagePath { get; set; }
        [NotMapped]
        public HttpFileCollectionBase anyName { get; set; }
    }
}
    
