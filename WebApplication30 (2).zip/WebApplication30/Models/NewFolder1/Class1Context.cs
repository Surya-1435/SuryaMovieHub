﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using WebApplication30.Models;

namespace WebApplication30.Models.NewFolder1
{
    public class Class1Context:DbContext
    {
        public Class1Context()
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Class1>().ToTable("pt1");
            modelBuilder.Entity<Class2>().ToTable("pt3");
        }
        public DbSet<Class1> result { get; set; }
        public DbSet<Class2> result2 { get; set; }
    }
}
    
