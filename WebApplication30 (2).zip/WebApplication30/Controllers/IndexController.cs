﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication30.Models;
using WebApplication30.Models.NewFolder1;

namespace WebApplication30.Controllers
{
    public class IndexController : Controller
    {

        Class1Context dal = new Class1Context();

        public ActionResult Index()
        {
            Class1 c = new Class1();
            List<Class1> li = dal.result.ToList();
            return View("Index", li);
        }
        public ActionResult Index2()
        {
            Class2 c = new Class2();
            List<Class2> li = dal.result2.ToList();
            return View("Indexer", li);
        }
        public ActionResult TvShows()
        {
            Class2 p = new Class2();
            return View("TvShows", p);
        }
        public ActionResult Create()
        {
            Class1 p = new Class1();
            return View("Create", p);
        }
        public ActionResult save(Class1 p)
        {
            p.anyName = Request.Files;
            HttpPostedFileBase a = p.anyName[0];
            string s = "~/images/store/" + a.FileName;
            p.ImagePath = s;
            a.SaveAs(Server.MapPath(p.ImagePath));
            dal.result.Add(p);
            dal.SaveChanges();
            List<Class1> li = dal.result.ToList();
            return View("Index", li);
        }
        public ActionResult down(Class2 p2)
        {
            p2.anyName = Request.Files;
            HttpPostedFileBase a = p2.anyName[0];
            string s = "~/images/store/" + a.FileName;
            p2.ImagePath = s;
            a.SaveAs(Server.MapPath(p2.ImagePath));
            dal.result2.Add(p2);
            dal.SaveChanges();
            List<Class2> li = dal.result2.ToList();
            return View("Indexer", li);
        }
        public ActionResult MovieDelete(string moviename)
        {
            Class1 d = dal.result.Find(moviename);
            dal.result.Remove(d);
            dal.SaveChanges();
            List<Class1> v = dal.result.ToList();
            return RedirectToAction("Index", v);
        }
        public ActionResult MovieDelete2(string moviename)
        {
            Class2 d = dal.result2.Find(moviename);
            dal.result2.Remove(d);
            dal.SaveChanges();
            List<Class2> v = dal.result2.ToList();
            return RedirectToAction("Index2", v);
        }
        public ActionResult Movieedit(string moviename)
        {
            Class1 d = dal.result.Find(moviename);
            if (d.MovieName.Equals(moviename)) 
            {
                Class1 v = new Class1();
                Class1 s = dal.result.Find(moviename); 
                v.MovieId = s.MovieId;
                v.MovieName= s.MovieName;
                v.MovieDescription= s.MovieDescription;
                v.trailer = s.trailer;                    
                return View("Movieedit", v);     
            }                                                  
            else
            {
                return View("Error");
            }
        }
        public ActionResult about()
        {
            Class1 c = new Class1();
            List<Class1> li = dal.result.ToList();
            return View("About", li);
        }
        public ActionResult Movieedit2(string moviename)
        {
            Class2 d = dal.result2.Find(moviename);
            if (d.MovieName.Equals(moviename))
            {
                Class2 v = new Class2();
                Class2 s = dal.result2.Find(moviename);
                v.MovieId = s.MovieId;
                v.MovieName = s.MovieName;
                v.MovieDescription = s.MovieDescription;
                v.trailer = s.trailer;
                return View("Movieedit2", v);
            }
            else
            {
                return View("Error");
            }
        }
       
            public ActionResult about2()
        {
            Class2 c = new Class2();
            List<Class2> li = dal.result2.ToList();
            return View("About2", li);
        }
        public ActionResult edit(Class1 p)
        {
            Class1 c = dal.result.Find(p.MovieName);
            c.MovieId = p.MovieId;
            c.MovieName = p.MovieName;
            c.MovieDescription = p.MovieDescription;
            c.trailer = p.trailer;
            dal.SaveChanges();
            List<Class1> a = dal.result.ToList();
            return RedirectToAction("Index", a);
        }
        public ActionResult edit2(Class2 p)
        {
            Class2 c = dal.result2.Find(p.MovieName);
            c.MovieId = p.MovieId;
            c.MovieName = p.MovieName;
            c.MovieDescription = p.MovieDescription;
            c.trailer = p.trailer;
            dal.SaveChanges();
            List<Class2> a = dal.result2.ToList();
           
            
            return View("Indexer", a);
        }
    }
}